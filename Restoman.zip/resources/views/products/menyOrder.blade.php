@extends('layouts.app')
@section('content')
    <div>
        Trần Văn Anh
    </div>
@endsection