<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body id="body">
    <div id="body-content" class="container-fluid">
        <div class="row body-all d-flex">
            <div class="col-1 p-0">
                <div id="sidebar" class="list-menu-db">
                    <header>
                        <div class="img-header">
                            <a href=index.html><img src="<?php echo e(asset('assets/img/logo.svg')); ?>"></a>
                        </div>
                        <ul class="">
                            <li class="">
                                <a href=<?php echo e(route('home')); ?>>
                                    <i id="icon-home" class="fa-solid fa-house-fire icon-header"></i>
                                </a>
                            </li>
                            <li class="">
                                <a href="<?php echo e(route('statistics')); ?>">
                                    <i id="icon-statistics" class="fa-solid fa-chart-pie icon-header"></i>
                                </a>
                            </li>
                            <li class="">
                                <a href="#">
                                    <i id="icon-history-order" class="fa-solid fa-clipboard icon-header"></i>
                                </a>
                            </li>
                            <li class="">
                                <a href="<?php echo e(route('product')); ?>">
                                    <i id="icon-product" class="fa-solid fa-burger icon-header"></i>
                                </a>
                            </li>
                            <li class="">
                                <a href="<?php echo e(route('info-user')); ?>">
                                    <i id="icon-user" class="fa-solid fa-users icon-header"></i>
                                </a>
                            </li>
                            <li class="">
                                <a href="<?php echo e(route('sale')); ?>">
                                    <i id="icon-sale" class="fa-solid fa-tags icon-header"></i>
                                </a>
                            </li>
                            <li class="">
                                <a href="#">
                                    <i id="icon-setting" class="fa-solid fa-gear icon-header"></i>
                                </a>
                            </li>
                        </ul>
                    </header>
                </div>
            </div>
    <?php echo $__env->yieldContent('content'); ?>
        </div>
    <?php echo $__env->yieldContent('bill'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Restoman\resources\views/layouts/layout.blade.php ENDPATH**/ ?>