
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sale.css')); ?>">   
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="body-all-sale">
        <div class="body-product-sale">
            <div class="title-sale">
                <span>Tạo sale sản phẩm</span>
            </div>
            <div class="body-product-sale-new">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="item-product" class="item-product">
                        <input type="hidden" name="product-id" value="<?php echo e($item['product']->id); ?>">
                        <input type="hidden" name="product->name" value="<?php echo e($item['product']->name); ?>">
                        <input type="hidden" name="product-img" value="<?php echo e($item['product']->img); ?>">
                        <input type="hidden" name="product-price" value="<?php echo e($item['product']->price); ?>">
                        <div class="item-info-product">
                            <div class="info-product-img">
                                <img src="<?php echo e(asset('assets/img/'.$item['product']->img.'')); ?>" alt="">
                            </div>
                            <div class="info-product-name">
                                <span><?php echo e($item['product']->name); ?></span> <br>
                                <span>ID : <?php echo e($item['product']->id); ?></span>
                            </div>
                        </div>
                        <div class="item-price">
                            <span><?php echo e($formattedPrice = number_format($item['product']->price, 0, ',', ',')); ?>đ</span>
                        </div>
                        <?php if($item['check'] == 1): ?>
                            <div class="icon-sale">
                                <span>SALE</span>
                            </div>
                        <?php endif; ?>
                    </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <input type="hidden" name="">
        </div>

        <div class="body-pick-sale">
            <div class="title-sale">
                <div id="button-show-sale" class="button-show-sale">
                   
                </div>
                <div id="body-show-product-sale" class="order-history-none">
                    <div id="body-back" class="order-history-back">
            
                    </div>
                    <div class="body-order-history">
                        <div class="history-order-title">
                            <div class="id-order-history">
                                <span>Sản phẩm sale</span>
                            </div>
                        </div>
                        <div class="history-order-product">
                            <span>Sản phẩm</span>
                            <div class="body-history-order-product">
                                <?php $__currentLoopData = $data_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-history-product">
                                        <div class="body-show">
                                            <div class="img-history-product">
                                                <img src="<?php echo e(asset('assets/img/'.$sale['product_sale']->img.'')); ?>" alt="">
                                            </div>
                                            <div class="info-history-product">
                                                <span><?php echo e($sale['product_sale']->name_sale); ?></span>
                                                <p><?php echo e($formattedPrice = number_format($sale['product_sale']->price_sale, 0, ',', ',')); ?>đ</p>
                                            </div>
                                        </div>
                                        <div class="">

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="item-body-pick-sale">
                
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="module" src="<?php echo e(asset('assets/js/sale.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Restoman\resources\views/sale/index.blade.php ENDPATH**/ ?>